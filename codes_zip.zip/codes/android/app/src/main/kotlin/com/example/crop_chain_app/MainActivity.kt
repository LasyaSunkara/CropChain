package com.example.crop_chain_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
