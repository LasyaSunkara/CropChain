import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/main_dashboard.dart';
import 'screens/dashboard_home.dart';
import 'screens/qr_scan_page.dart';
import 'screens/search_screen.dart';
import 'screens/library_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/supplier_details_screen.dart';
import 'screens/sensor_details.dart';


void main() {
  runApp(const CropChainApp());
}

class CropChainApp extends StatelessWidget {
  const CropChainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Crop Chain',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFFDFF5D6),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const WelcomeScreen(),
        '/supplier': (context) => const SupplierDetailsScreen(),
        '/splash': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const MainDashboard(),
        '/dashboard': (context) => const DashboardHome(),
        '/search': (context) => const SearchScreen(),
        '/library': (context) => const LibraryScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/scan': (context) => const QRScanPage(),
        '/sensor-details': (context) => const SensorDetailsScreen(),
      },
    );
  }
}
