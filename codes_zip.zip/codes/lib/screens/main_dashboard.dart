import 'package:flutter/material.dart';
import 'dashboard_home.dart';

class MainDashboard extends StatelessWidget {
  const MainDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    // Only return DashboardHome, which already has Scaffold and BottomNavigationBar
    return const DashboardHome();
  }
}
