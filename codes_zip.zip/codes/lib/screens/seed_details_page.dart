import 'package:flutter/material.dart';
import '../../data/seed_data.dart';
import '../../services/blockchain_service.dart';
import '../../services/thingspeak_helper.dart';

class SeedDetailsPage extends StatefulWidget {
  final String qrData;
  const SeedDetailsPage({super.key, required this.qrData});

  @override
  State<SeedDetailsPage> createState() => _SeedDetailsPageState();
}

class _SeedDetailsPageState extends State<SeedDetailsPage> {
  late SeedData seed;
  String blockchainError = '';
  Map<String, dynamic>? blockchainInfo;
  Map<String, String> sensorData = {
    'temperature': '--',
    'humidity': '--',
    'soil_moisture': '--',
    'timestamp': '--'
  };
  bool isLoadingSensor = true;

  @override
  void initState() {
    super.initState();
    seed = seedDatabase.firstWhere(
      (s) => s.qrCode == widget.qrData,
      orElse: () => SeedData.empty(),
    );
    _loadData();
  }

  Future<void> _loadData() async {
    await Future.wait([
      _fetchBlockchainDetails(),
      _fetchSensorData(),
    ]);
  }

  Future<void> _fetchBlockchainDetails() async {
    try {
      final blockchain = BlockchainService();
      await blockchain.init();
      final data = await blockchain.getSeedData(widget.qrData);

      setState(() {
        blockchainInfo = data;
        // Only update fields we get from blockchain, keeping rest from database
        seed = SeedData(
          qrCode: widget.qrData,
          seedName: data["seedName"] ?? seed.seedName,
          variety: seed.variety,
          batchNumber: data["batchNo"] ?? seed.batchNumber,
          supplier: data["supplier"] ?? seed.supplier,
          contact: seed.contact,
          manufactureDate: seed.manufactureDate,
          expiryDate: seed.expiryDate,
          authenticity: seed.authenticity,
          blockchainLog: seed.blockchainLog,
          certification: seed.certification,
          tamperStatus: seed.tamperStatus,
          germinationRate: seed.germinationRate,
          purity: seed.purity,
          resistance: seed.resistance,
          contamination: seed.contamination,
          idealTemp: seed.idealTemp,
          moistureLimit: seed.moistureLimit,
          lightSensitivity: seed.lightSensitivity,
          sensorData: data["sensorType"] != null && data["sensorValue"] != null
              ? '${data["sensorType"]}: ${data["sensorValue"]}'
              : seed.sensorData,
          soilType: seed.soilType,
          sowingSeason: seed.sowingSeason,
          spacingDepth: seed.spacingDepth,
          watering: seed.watering,
          harvestTime: seed.harvestTime,
          currentLocation: seed.currentLocation,
          transportHistory: seed.transportHistory,
          gpsTamperStatus: seed.gpsTamperStatus,
          pricePerKg: seed.pricePerKg,
          bulkOffers: seed.bulkOffers,
          nearbyStores: seed.nearbyStores,
          rating: seed.rating,
          fakeReports: seed.fakeReports,
        );
      });
    } catch (e) {
      setState(() => blockchainError = "Chain found");
    }
  }

  Future<void> _fetchSensorData() async {
    try {
      final response = await ThingSpeakHelper.getLatestData();
      setState(() {
        sensorData = {
          'temperature': '${response['field1'] ?? '--'}°C',
          'humidity': '${response['field2'] ?? '--'}%',
          'soil_moisture': '${response['field3'] ?? '--'}%',
          'timestamp': response['created_at']?.toString() ?? 'Just now',
        };
        isLoadingSensor = false;
      });
    } catch (e) {
      setState(() {
        sensorData = {
          'temperature': 'Error',
          'humidity': 'Error',
          'soil_moisture': 'Error',
          'timestamp': 'Update failed',
        };
        isLoadingSensor = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F8EC),
      appBar: AppBar(
        title: Text('${seed.seedName} Details'),
        backgroundColor: const Color(0xFF77b978),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (blockchainError.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(blockchainError, style: const TextStyle(color: Color.fromARGB(255, 77, 245, 58))),
              ),

            _buildSection('🌡️ Live Crop Conditions', [
              if (isLoadingSensor)
                const Center(child: CircularProgressIndicator())
              else
                Column(
                  children: [
                    _buildInfo('Temperature', sensorData['temperature']!),
                    _buildInfo('Humidity', sensorData['humidity']!),
                    _buildInfo('Soil Moisture', sensorData['soil_moisture']!),
                    _buildInfo('Last Updated', sensorData['timestamp']!),
                  ],
                ),
            ]),

            _buildSection('🔍 Basic Info', [
              _buildInfo('Seed Name', seed.seedName),
              _buildInfo('Variety', seed.variety),
              _buildInfo('Batch Number', seed.batchNumber),
              _buildInfo('Supplier', seed.supplier),
              _buildInfo('Manufacture Date', seed.manufactureDate),
              _buildInfo('Expiry Date', seed.expiryDate),
            ]),

            _buildSection('✅ Blockchain Verification', [
              _buildInfo('Authenticity', seed.authenticity),
              ...seed.blockchainLog.map((e) => _buildInfo('Log', e)),
              _buildInfo('Certification', seed.certification),
              _buildInfo('Tamper Status', seed.tamperStatus),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Color(0xFF46CC5D),
            ),
          ),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '$label: ',
              style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
            ),
            TextSpan(
              text: value,
              style: const TextStyle(color: Colors.black87),
            ),
          ],
        ),
      ),
    );
  }
}
