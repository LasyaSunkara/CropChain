import 'package:flutter/material.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController searchController = TextEditingController();
  final List<String> seeds = [
    'Wheat', 'Maize', 'Millets', 'Moong Dal', // Dry seeds
    'Urad Dal', 'Ground Nut', 'Cotton', 'Potato',
    'Paddy', 'Green Gram', 'Black Gram' // Wet seeds
  ];

  String query = '';

  @override
  Widget build(BuildContext context) {
    final filteredSeeds = seeds
        .where((seed) => seed.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255), // ✅ Earthy green background
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 🔍 Search bar
                Container(
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 197, 197, 197), // ✅ Soft pastel box
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: TextField(
                    controller: searchController,
                    onChanged: (value) => setState(() => query = value),
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search, color: Colors.black54),
                      hintText: "Search for any seed name...",
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.all(16),
                      hintStyle: TextStyle(color: Colors.black54),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // 🌱 SEEDS label
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("SEEDS", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Icon(Icons.arrow_forward_ios, size: 16),
                  ],
                ),
                const SizedBox(height: 10),

                // Grid of seed names
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 2.8,
                  children: filteredSeeds.map((seed) {
                    return Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 121, 187, 131).withOpacity(0.3),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        seed,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 24),

                // 🧺 SUPPLIERS label
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("SUPPLIERS", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Icon(Icons.arrow_forward_ios, size: 16),
                  ],
                ),
                const SizedBox(height: 12),

                Row(
                  children: [
                    buildSupplierCard("10 popular suppliers in India..."),
                    const SizedBox(width: 12),
                    buildSupplierCard("Native varieties (breeds)..."),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildSupplierCard(String label) {
    return Expanded(
      child: Container(
        height: 130,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 119, 172, 190).withOpacity(0.2),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Center(
          child: Text(
            label,
            style: const TextStyle(fontSize: 14),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
