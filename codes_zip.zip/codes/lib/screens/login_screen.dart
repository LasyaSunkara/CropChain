import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/user_info.dart'; // Make sure this file exists and is correct

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  DateTime? selectedDOB;
  String? selectedGender;

  final List<String> genders = ['Male', 'Female', 'Other'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/icon/logpic.png',
              height: 200,
            ),
            const SizedBox(height: 20),
            const Text(
              'Enter your details',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 30),

            // Name input
            buildFieldContainer(
              child: TextField(
                controller: nameController,
                decoration: inputDecoration('Enter your name :'),
              ),
            ),
            const SizedBox(height: 16),

            // Gender dropdown
            buildFieldContainer(
              child: DropdownButtonFormField<String>(
                value: selectedGender,
                decoration: inputDecoration('Enter gender :'),
                icon: const Icon(Icons.arrow_drop_down),
                items: genders.map((String gender) {
                  return DropdownMenuItem<String>(
                    value: gender,
                    child: Text(gender),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() => selectedGender = value);
                },
              ),
            ),
            const SizedBox(height: 16),

            // DOB picker
            buildFieldContainer(
              child: GestureDetector(
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime(2000),
                    firstDate: DateTime(1900),
                    lastDate: DateTime.now(),
                  );
                  if (picked != null) {
                    setState(() => selectedDOB = picked);
                  }
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    decoration: inputDecoration('Enter date of birth :'),
                    controller: TextEditingController(
                      text: selectedDOB != null
                          ? DateFormat('dd-MM-yyyy').format(selectedDOB!)
                          : '',
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Location input
            buildFieldContainer(
              child: TextField(
                controller: locationController,
                decoration: inputDecoration('Select your location :'),
              ),
            ),

            const SizedBox(height: 30),

            // Enter button
            ElevatedButton(
              onPressed: () {
                UserInfo.setUser(
                  userName: nameController.text,
                  userGender: selectedGender ?? '',
                  userDOB: selectedDOB != null
                      ? DateFormat('dd-MM-yyyy').format(selectedDOB!)
                      : '',
                  userLocation: locationController.text,
                );
                Navigator.pushNamed(context, '/home');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF86D965),
                padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text("Enter", style: TextStyle(color: Colors.black)),
            ),
            const SizedBox(height: 20),

            // Already have a profile link
            GestureDetector(
              onTap: () {
                Navigator.pushReplacementNamed(context, '/home');
              },
              child: const Text(
                'Already have a profile? Continue here',
                style: TextStyle(
                  color: Color(0xFF77A9B9),
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildFieldContainer({required Widget child}) {
    return Container(
      height: 58,
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFF77B99C),
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      alignment: Alignment.center,
      child: child,
    );
  }

  InputDecoration inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.black),
      border: InputBorder.none,
    );
  }
}
