import 'package:flutter/material.dart';

class SeedEntryScreen extends StatefulWidget {
  final String supplierName;
  final String supplierContact;
  final String supplierLocation;

  const SeedEntryScreen({
    super.key,
    required this.supplierName,
    required this.supplierContact,
    required this.supplierLocation,
  });

  @override
  State<SeedEntryScreen> createState() => _SeedEntryScreenState();
}

class _SeedEntryScreenState extends State<SeedEntryScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController seedNameController = TextEditingController();
  final TextEditingController varietyController = TextEditingController();
  final TextEditingController batchNumberController = TextEditingController();
  final TextEditingController placeController = TextEditingController();
  DateTime? manufactureDate;
  DateTime? expiryDate;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFDFF5D6),
      appBar: AppBar(
        title: const Text('Seed Entry'),
        backgroundColor: const Color(0xFF77b978),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              buildField(seedNameController, "Seed Name"),
              const SizedBox(height: 16),
              buildField(varietyController, "Variety"),
              const SizedBox(height: 16),
              buildField(batchNumberController, "Batch Number"),
              const SizedBox(height: 16),
              buildDatePicker("Manufacture Date", manufactureDate, (picked) {
                setState(() => manufactureDate = picked);
              }),
              const SizedBox(height: 16),
              buildDatePicker("Expiry Date (optional)", expiryDate, (picked) {
                setState(() => expiryDate = picked);
              }),
              const SizedBox(height: 16),
              buildField(placeController, "Place of Seed Generation"),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    // You can handle submission or saving here
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Seed Registered'),
                        content: Text(
                          'Seed "${seedNameController.text}" from supplier "${widget.supplierName}" has been successfully added!',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/home')),
                            child: const Text('OK'),
                          )
                        ],
                      ),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF86D965),
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: const Text("Submit", style: TextStyle(color: Colors.black)),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: const Color(0xFF77B99C),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        labelStyle: const TextStyle(color: Colors.black),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        }
        return null;
      },
    );
  }

  Widget buildDatePicker(String label, DateTime? date, ValueChanged<DateTime> onPicked) {
    return GestureDetector(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(2000),
          lastDate: DateTime(2100),
        );
        if (picked != null) {
          onPicked(picked);
        }
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: const Color(0xFF77B99C),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          labelStyle: const TextStyle(color: Colors.black),
        ),
        child: Text(
          date != null ? "${date.day}-${date.month}-${date.year}" : "Select date",
          style: const TextStyle(color: Colors.black),
        ),
      ),
    );
  }
}
