import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/user_info.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late Timer timer;
  DateTime currentTime = DateTime.now();
  bool showSettings = false;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        currentTime = DateTime.now();
      });
    });
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  String getGreeting() {
    final hour = currentTime.hour;
    if (hour < 12) return 'GOOD MORNING...';
    if (hour < 17) return 'GOOD AFTERNOON...';
    return 'GOOD EVENING...';
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => true,
      child: Scaffold(
        backgroundColor: const Color(0xFFDFF5D6),
        appBar: AppBar(
          title: const Text("Profile"),
          backgroundColor: const Color(0xFF77b978),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () {
                setState(() => showSettings = !showSettings);
              },
            )
          ],
        ),
        body: Stack(
          children: [
            ListView(
              padding: const EdgeInsets.all(20),
              children: [
                CircleAvatar(
                  radius: 65,
                  backgroundImage: const AssetImage('assets/icon/profile.jpg'),
                ),
                const SizedBox(height: 10),
                Column(
                  children: [
                    Text(
                    "Hello, ${UserInfo.name}..!",
                    style: const TextStyle(fontSize: 20),
                  ),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () => showEditDialog(context),
                  child: const Text(
                    "Edit profile ✏️",
                    style: TextStyle(
                      color: Color(0xFF77a9b9),
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
                const SizedBox(height: 30),
                Center(
                  child: Column(
                    children: [
                      Text(getGreeting(),
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CustomPaint(
                          painter: AnalogClockPainter(currentTime),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                buildActionBtn('Saved profiles', Icons.bookmark),
                buildActionBtn('Favorites', Icons.favorite),
                buildActionBtn('Starred profiles', Icons.star),
              ],
            ),
            if (showSettings)
              Positioned(
                right: 10,
                top: 70,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  width: 220,
                  decoration: BoxDecoration(
                    color: const Color(0xFF77A9B9),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text("Settings", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      SizedBox(height: 8),
                      Text("Profile Information"),
                      Text("Theme"),
                      Text("Language"),
                      Text("Notification Sound"),
                      Text("Password"),
                      Text("Privacy Settings"),
                      Text("Permissions"),
                      Text("Data Usage"),
                      Text("Font & Style"),
                      Text("Terms of Service"),
                      Text("Help"),
                    ],
                  ),
                ),
              )
          ],
        ),
      ),
    );
  }

  void showEditDialog(BuildContext context) {
    final nameCtrl = TextEditingController(text: UserInfo.name);
    final locationCtrl = TextEditingController(text: UserInfo.location);
    String gender = UserInfo.gender;
    DateTime? dob;
    try {
      dob = DateFormat('dd-MM-yyyy').parse(UserInfo.dob);
    } catch (_) {
      dob = DateTime(2000);
    }

    showDialog(
      context: context,
      builder: (_) => Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 350),
          child: AlertDialog(
            backgroundColor: const Color(0xFF77b99c),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Center(
                child: Text("Edit Profile", style: TextStyle(fontWeight: FontWeight.bold))),
            content: StatefulBuilder(
              builder: (context, setModalState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Name',
                        filled: true,
                        fillColor: Color(0xFF77a9b9),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: gender.isNotEmpty ? gender : null,
                      decoration: const InputDecoration(
                        labelText: 'Gender',
                        filled: true,
                        fillColor: Color(0xFF77a9b9),
                        border: OutlineInputBorder(),
                      ),
                      items: ['Male', 'Female', 'Other'].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (val) => setModalState(() => gender = val!),
                    ),
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: dob!,
                          firstDate: DateTime(1900),
                          lastDate: DateTime.now(),
                        );
                        if (picked != null) {
                          setModalState(() => dob = picked);
                        }
                      },
                      child: AbsorbPointer(
                        child: TextFormField(
                          controller: TextEditingController(
                            text: dob != null ? DateFormat('dd-MM-yyyy').format(dob!) : '',
                          ),
                          decoration: const InputDecoration(
                            labelText: 'Date of Birth',
                            filled: true,
                            fillColor: Color(0xFF77a9b9),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: locationCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Location',
                        filled: true,
                        fillColor: Color(0xFF77a9b9),
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                );
              },
            ),
            actions: [
              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF86D965),
                  ),
                  onPressed: () {
                    setState(() {
                      UserInfo.setUser(
                        userName: nameCtrl.text,
                        userGender: gender,
                        userDOB: DateFormat('dd-MM-yyyy').format(dob!),
                        userLocation: locationCtrl.text,
                      );
                    });
                    Navigator.pop(context);
                  },
                  child: const Text('Save', style: TextStyle(color: Colors.black)),
                ),
              )
            ],
          ),
        ),
      ),
    );

  }

  Widget buildActionBtn(String label, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: ElevatedButton.icon(
        onPressed: () {},
        icon: Icon(icon, color: Colors.black),
        label: Text(label, style: const TextStyle(color: Colors.black)),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF86D965),
          minimumSize: const Size(double.infinity, 50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
    );
  }
}

class AnalogClockPainter extends CustomPainter {
  final DateTime time;
  AnalogClockPainter(this.time);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paintCircle = Paint()..color = Colors.white;
    final border = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4;

    final hourHand = Paint()
      ..color = Colors.black
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;

    final minuteHand = Paint()
      ..color = Colors.black
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;

    final secondHand = Paint()
      ..color = Colors.red
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, paintCircle);
    canvas.drawCircle(center, radius, border);

    final hourAngle = ((time.hour % 12 + time.minute / 60) * 30 - 90) * pi / 180;
    final minAngle = (time.minute * 6 - 90) * pi / 180;
    final secAngle = (time.second * 6 - 90) * pi / 180;

    canvas.drawLine(center, center + Offset(cos(hourAngle), sin(hourAngle)) * radius * 0.4, hourHand);
    canvas.drawLine(center, center + Offset(cos(minAngle), sin(minAngle)) * radius * 0.6, minuteHand);
    canvas.drawLine(center, center + Offset(cos(secAngle), sin(secAngle)) * radius * 0.7, secondHand);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
