// lib/screens/seed_detail_screen.dart
import 'package:flutter/material.dart';
import '../data/seed_data.dart';

class SeedDetailScreen extends StatelessWidget {
  final String qrData;
  const SeedDetailScreen({super.key, required this.qrData});

  @override
  Widget build(BuildContext context) {
    final seed = seedDatabase.firstWhere(
      (s) => s.qrCode == qrData,
      orElse: () => SeedData.empty(),
    );

    return Scaffold(
      backgroundColor: const Color(0xFFF0F8EC),
      appBar: AppBar(
        title: Text('${seed.seedName} Details'),
        backgroundColor: const Color(0xFF77b978),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sectionTitle("🔍 Basic Seed Information"),
            infoTile("Seed Name & Variety", "${seed.seedName} (${seed.variety})"),
            infoTile("Batch No", seed.batchNumber),
            infoTile("Supplier", "${seed.supplier} (${seed.contact})"),
            infoTile("Manufacture Date", seed.manufactureDate),
            infoTile("Expiry Date", seed.expiryDate),

            sectionTitle("✅ Authenticity & Blockchain Verification"),
            infoTile("Status", seed.authenticity),
            for (var log in seed.blockchainLog) infoTile("Log", log),
            infoTile("Certification", seed.certification),
            infoTile("Tamper Status", seed.tamperStatus),

            sectionTitle("🧪 Seed Quality & Lab Tests"),
            infoTile("Germination Rate", seed.germinationRate),
            infoTile("Purity", seed.purity),
            infoTile("Resistance", seed.resistance),
            infoTile("Contamination", seed.contamination),

            sectionTitle("📦 Storage & Environmental Conditions"),
            infoTile("Ideal Temp", seed.idealTemp),
            infoTile("Moisture Limit", seed.moistureLimit),
            infoTile("Light Sensitivity", seed.lightSensitivity),
            infoTile("IoT Sensor Data", seed.sensorData),

            sectionTitle("🌱 Planting Guidelines"),
            infoTile("Soil Type", seed.soilType),
            infoTile("Sowing Season", seed.sowingSeason),
            infoTile("Spacing & Depth", seed.spacingDepth),
            infoTile("Watering", seed.watering),
            infoTile("Harvest Time", seed.harvestTime),

            sectionTitle("📍 GPS & Supply Chain"),
            infoTile("Current Location", seed.currentLocation),
            for (var move in seed.transportHistory) infoTile("Movement", move),
            infoTile("GPS Tamper Status", seed.gpsTamperStatus),

            sectionTitle("💰 Pricing & Offers"),
            infoTile("Price Per Kg", seed.pricePerKg),
            infoTile("Bulk Offers", seed.bulkOffers),
            for (var store in seed.nearbyStores) infoTile("Nearby Store", store),

            sectionTitle("⭐ Farmer Reviews"),
            infoTile("Average Rating", seed.rating),
            infoTile("Fake Report Status", seed.fakeReports),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF46cc5d)),
      ),
    );
  }

  Widget infoTile(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(text: "$label: ", style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w600)),
            TextSpan(text: value, style: const TextStyle(color: Colors.black87)),
          ],
        ),
      ),
    );
  }
}
