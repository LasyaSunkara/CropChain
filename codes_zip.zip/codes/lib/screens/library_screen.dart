// lib/screens/library_screen.dart
import 'package:flutter/material.dart';
import '../data/activity_history.dart';
import '../data/seed_data.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> scannedQRCodes = ActivityHistory.getAll();

    return Scaffold(
      backgroundColor: const Color(0xFFDFF5D6),
      appBar: AppBar(
        title: const Text('Library'),
        backgroundColor: const Color(0xFF77b978),
        actions: [
          if (scannedQRCodes.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () {
                ActivityHistory.clearHistory();
                Navigator.pushReplacementNamed(context, '/library');
              },
            ),
        ],
      ),
      body: scannedQRCodes.isEmpty
          ? const Center(
              child: Text(
                "No activity yet.",
                style: TextStyle(fontSize: 18, color: Colors.black54),
              ),
            )
          : ListView.builder(
              itemCount: scannedQRCodes.length,
              itemBuilder: (context, index) {
                final qr = scannedQRCodes[index];
                final match = seedDatabase.where((s) => s.qrCode == qr);

                if (match.isEmpty) {
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    color: Colors.red[100],
                    child: const ListTile(
                      title: Text(
                        'Invalid QR Code',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('Please scan a valid seed QR code.'),
                    ),
                  );
                }

                final seed = match.first;
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  color: const Color(0xFF77B99C),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    title: Text(
                      seed.seedName,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 6),
                        Text("Batch No: ${seed.batchNumber}"),
                        Text("Supplier: ${seed.supplier}"),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
