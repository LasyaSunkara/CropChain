import 'package:flutter/material.dart';
import '../services/thingspeak_helper.dart';

class SensorDetailsScreen extends StatefulWidget {
  const SensorDetailsScreen({super.key});

  @override
  State<SensorDetailsScreen> createState() => _SensorDetailsScreenState();
}

class _SensorDetailsScreenState extends State<SensorDetailsScreen> {
  Map<String, dynamic> sensorData = {
    'temperature': '--',
    'humidity': '--',
    'soilMoisture': '--',
    'timestamp': 'Not available'
  };
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchSensorData();
  }

  Future<void> _fetchSensorData() async {
    try {
      setState(() {
        isLoading = true;
        errorMessage = null;
      });

      // Get data from ThingSpeak
      final response = await ThingSpeakHelper.getLatestData();

      setState(() {
        sensorData = {
          'temperature': response['field1'] ?? '--',
          'humidity': response['field2'] ?? '--',
          'soilMoisture': response['field3'] ?? '--',
          'timestamp': response['created_at'] ?? 'Just now',
        };
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to load sensor data';
        isLoading = false;
      });
      debugPrint('Error fetching sensor data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Crop Conditions'),
        backgroundColor: const Color(0xFF77b978),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchSensorData,
            tooltip: 'Refresh data',
          ),
        ],
      ),
      body: _buildBodyContent(),
    );
  }

  Widget _buildBodyContent() {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(errorMessage!, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fetchSensorData,
              child: const Text('Try Again'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSensorData,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildSensorCard(
            title: 'Temperature',
            value: '${sensorData['temperature']}°C',
            icon: Icons.thermostat,
            color: Colors.orange,
          ),
          _buildSensorCard(
            title: 'Humidity',
            value: '${sensorData['humidity']}%',
            icon: Icons.water_drop,
            color: Colors.blue,
          ),
          _buildSensorCard(
            title: 'Soil Moisture',
            value: '${sensorData['soilMoisture']}%',
            icon: Icons.grass,
            color: const Color(0xFF77b978),
          ),
          const SizedBox(height: 20),
          Text(
            'Last updated: ${sensorData['timestamp']}',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[600],
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSensorCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, size: 36, color: color),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}