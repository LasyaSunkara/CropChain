class SeedData {
  final String qrCode;
  final String seedName;
  final String supplier;
  final String type; // Wet or Dry
  final String batchNumber;
  final String expiryDate;
  final String quality;

  SeedData({
    required this.qrCode,
    required this.seedName,
    required this.supplier,
    required this.type,
    required this.batchNumber,
    required this.expiryDate,
    required this.quality,
  });
}
