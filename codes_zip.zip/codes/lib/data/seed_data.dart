class SeedData {
  final String qrCode;
  final String seedName;
  final String variety;
  final String batchNumber;
  final String supplier;
  final String contact;
  final String manufactureDate;
  final String expiryDate;
  final String authenticity;
  final List<String> blockchainLog;
  final String certification;
  final String tamperStatus;
  final String germinationRate;
  final String purity;
  final String resistance;
  final String contamination;
  final String idealTemp;
  final String moistureLimit;
  final String lightSensitivity;
  final String sensorData;
  final String soilType;
  final String sowingSeason;
  final String spacingDepth;
  final String watering;
  final String harvestTime;
  final String currentLocation;
  final List<String> transportHistory;
  final String gpsTamperStatus;
  final String pricePerKg;
  final String bulkOffers;
  final List<String> nearbyStores;
  final String rating;
  final String fakeReports;

  const SeedData({
    required this.qrCode,
    required this.seedName,
    required this.variety,
    required this.batchNumber,
    required this.supplier,
    required this.contact,
    required this.manufactureDate,
    required this.expiryDate,
    required this.authenticity,
    required this.blockchainLog,
    required this.certification,
    required this.tamperStatus,
    required this.germinationRate,
    required this.purity,
    required this.resistance,
    required this.contamination,
    required this.idealTemp,
    required this.moistureLimit,
    required this.lightSensitivity,
    required this.sensorData,
    required this.soilType,
    required this.sowingSeason,
    required this.spacingDepth,
    required this.watering,
    required this.harvestTime,
    required this.currentLocation,
    required this.transportHistory,
    required this.gpsTamperStatus,
    required this.pricePerKg,
    required this.bulkOffers,
    required this.nearbyStores,
    required this.rating,
    required this.fakeReports,
  });

  factory SeedData.empty() => SeedData(
        qrCode: '',
        seedName: 'Unknown',
        variety: '',
        batchNumber: '',
        supplier: '',
        contact: '',
        manufactureDate: '',
        expiryDate: '',
        authenticity: '',
        blockchainLog: [],
        certification: '',
        tamperStatus: '',
        germinationRate: '',
        purity: '',
        resistance: '',
        contamination: '',
        idealTemp: '',
        moistureLimit: '',
        lightSensitivity: '',
        sensorData: '',
        soilType: '',
        sowingSeason: '',
        spacingDepth: '',
        watering: '',
        harvestTime: '',
        currentLocation: '',
        transportHistory: [],
        gpsTamperStatus: '',
        pricePerKg: '',
        bulkOffers: '',
        nearbyStores: [],
        rating: '',
        fakeReports: '',
      );
}

final seedDatabase = [
  // Bajra Seed (Dry)
  SeedData(
    qrCode: 'ud0JBCURKg',
    seedName: 'Bajra Seed',
    variety: 'Pearl Millet',
    batchNumber: 'BJ2024-01',
    supplier: 'AgriGrowth Pvt. Ltd.',
    contact: '+91-9876543210',
    manufactureDate: 'March 2024',
    expiryDate: 'March 2025',
    authenticity: 'Verified (Blockchain Secured)',
    blockchainLog: [
      'Harvested at Rajasthan Fields (Feb 2024)',
      'Stored at Jaipur Cold Storage (March 2024)',
      'Delivered to Hyderabad Warehouse (April 2024)',
    ],
    certification: 'ISO 22000, Agmark Certified',
    tamperStatus: 'No tampering detected',
    germinationRate: '90%',
    purity: '98%',
    resistance: 'Drought Resistant',
    contamination: 'None detected',
    idealTemp: '20–28°C',
    moistureLimit: '<10%',
    lightSensitivity: 'Store away from direct sunlight',
    sensorData: 'Temperature: 24°C, Humidity: 46%',
    soilType: 'Sandy Loam Soil',
    sowingSeason: 'June–July',
    spacingDepth: '45 cm apart, 4 cm deep',
    watering: 'Moderate Watering',
    harvestTime: '80–90 days',
    currentLocation: 'Hyderabad Agri Depot',
    transportHistory: [
      'From Rajasthan to Jaipur (Feb 2024)',
      'Jaipur to Hyderabad (April 2024)',
    ],
    gpsTamperStatus: 'GPS verified',
    pricePerKg: '₹70',
    bulkOffers: 'Buy 50kg, Get 5kg Free',
    nearbyStores: ['AgriMart Hyderabad', 'Farmers’ Market'],
    rating: '4.5/5 (200+ reviews)',
    fakeReports: 'Zero',
  ),

  // Hibiscus Seeds (Wet)
  SeedData(
    qrCode: 'je9SPquWCt',
    seedName: 'Hibiscus Seed',
    variety: 'Roselle',
    batchNumber: 'HS2024-02',
    supplier: 'Flora Farms Ltd.',
    contact: '+91-9123456789',
    manufactureDate: 'Feb 2024',
    expiryDate: 'Feb 2025',
    authenticity: 'Blockchain Verified',
    blockchainLog: [
      'Produced at Kerala Hibiscus Plantations (Jan 2024)',
      'Quality Check at Cochin Labs (Feb 2024)',
    ],
    certification: 'Organic Certified',
    tamperStatus: 'Passed all security checks',
    germinationRate: '92%',
    purity: '99%',
    resistance: 'Resistant to Leaf Spot Disease',
    contamination: 'None',
    idealTemp: '22–26°C',
    moistureLimit: '<13%',
    lightSensitivity: 'Keep in shade',
    sensorData: 'Soil Moisture: 72%',
    soilType: 'Loamy Soil',
    sowingSeason: 'May–June',
    spacingDepth: '30 cm apart, 2 cm deep',
    watering: 'High (Needs regular watering)',
    harvestTime: '100–120 days',
    currentLocation: 'Cochin Seed Store',
    transportHistory: [
      'From Kerala Plantation to Cochin (Feb 2024)',
    ],
    gpsTamperStatus: 'No issues detected',
    pricePerKg: '₹200',
    bulkOffers: '15% off for 20kg+ orders',
    nearbyStores: ['Flora Mart', 'Organic Seed House'],
    rating: '4.8/5 (180+ reviews)',
    fakeReports: 'None',
  ),

  // Sunflower Seeds (Dry)
  SeedData(
    qrCode: '1kyXx9Q9Zr',
    seedName: 'Sunflower Seed',
    variety: 'SunBright Hybrid',
    batchNumber: 'SF2024-03',
    supplier: 'Sunshine Agro',
    contact: '+91-9988776655',
    manufactureDate: 'Jan 2024',
    expiryDate: 'Jan 2025',
    authenticity: 'Verified with Blockchain',
    blockchainLog: [
      'Harvested from Maharashtra Fields (Dec 2023)',
      'Shipped to Nagpur Storage (Jan 2024)',
    ],
    certification: 'ICAR Approved',
    tamperStatus: 'Verified – No tampering',
    germinationRate: '94%',
    purity: '98.5%',
    resistance: 'Mild Pest Resistance',
    contamination: 'Safe',
    idealTemp: '18–25°C',
    moistureLimit: '<11%',
    lightSensitivity: 'Protect from direct light',
    sensorData: 'Temperature: 26°C, Humidity: 44%',
    soilType: 'Well-drained Loamy Soil',
    sowingSeason: 'January–February',
    spacingDepth: '25 cm apart, 5 cm deep',
    watering: 'Medium (twice a week)',
    harvestTime: '90–100 days',
    currentLocation: 'Nagpur Agro Center',
    transportHistory: [
      'Transported from Field to Nagpur Depot (Jan 2024)',
    ],
    gpsTamperStatus: 'Verified OK',
    pricePerKg: '₹120',
    bulkOffers: '10% off above 30kg',
    nearbyStores: ['Sun Agro Store', 'Nagpur Farming Supplies'],
    rating: '4.4/5 (160 reviews)',
    fakeReports: 'Zero',
  ),
];
