class UserInfo {
  static String name = '';
  static String gender = '';
  static String dob = '';
  static String location = '';

  static void setUser({
    required String userName,
    required String userGender,
    required String userDOB,
    required String userLocation,
  }) {
    name = userName;
    gender = userGender;
    dob = userDOB;
    location = userLocation;
  }
}
