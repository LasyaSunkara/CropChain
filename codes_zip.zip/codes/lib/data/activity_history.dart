class ActivityHistory {
  static final List<String> _history = [];

  static void add(String qrCode) {
    _history.add(qrCode);
  }

  static List<String> getAll() {
    return _history.reversed.toList(); // newest first
  }

  static void clearHistory() {
    _history.clear();
  }
}
