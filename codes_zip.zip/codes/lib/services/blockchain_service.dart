// lib/services/blockchain_service.dart
import 'dart:convert';
import 'package:web3dart/web3dart.dart';
import 'package:http/http.dart' as http;

class BlockchainService {
  late Web3Client _client;
  late DeployedContract _contract;
  late ContractFunction _getSeed;

  final String rpcUrl = 'http://127.0.0.1:7545';
  final String contractAddress = '0xe77f1B145920f67B92297da72419AA8a8461B41c';

  final abi = jsonEncode([
    {[
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "qrCode",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "seedName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "batchNo",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "supplier",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "sensorType",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "sensorValue",
				"type": "string"
			}
		],
		"name": "addSeed",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "qrCode",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "seedName",
				"type": "string"
			}
		],
		"name": "SeedLogged",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "qrCode",
				"type": "string"
			}
		],
		"name": "getSeed",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"name": "seeds",
		"outputs": [
			{
				"internalType": "string",
				"name": "seedName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "batchNo",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "supplier",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "sensorType",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "sensorValue",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "timestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]
    }
  ]);

  Future<void> init() async {
    _client = Web3Client(rpcUrl, http.Client());
    _contract = DeployedContract(
      ContractAbi.fromJson(abi, 'SeedStorage'),
      EthereumAddress.fromHex(contractAddress),
    );
    _getSeed = _contract.function('getSeed');
  }

  Future<Map<String, dynamic>> getSeedData(String qrCode) async {
    final response = await _client.call(
      contract: _contract,
      function: _getSeed,
      params: [qrCode],
    );

    return {
      "seedName": response[0] as String,
      "batchNo": response[1] as String,
      "supplier": response[2] as String,
      "sensorType": response[3] as String,
      "sensorValue": response[4] as String,
    };
  }
}
