// lib/services/thingspeak_helper.dart
import 'package:http/http.dart' as http;
import 'dart:convert';

class ThingSpeakHelper {
  static const String _channelId = '2935821'; // Replace your channel ID
  static const String _apiKey = 'Q3JMS83FW4NT5CX5'; // Replace your Read API Key

  static Future<Map<String, dynamic>> getLatestData() async {
    final response = await http.get(Uri.parse(
      'https://api.thingspeak.com/channels/$_channelId/feeds/last.json?api_key=$_apiKey'
    ));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return {
        'field1': data['field1'], // Temperature
        'field2': data['field2'], // Humidity
        'field3': data['field3'], // Soil Moisture
        'created_at': data['created_at'],
      };
    } else {
      throw Exception('Failed to load Thingspeak data');
    }
  }
}
