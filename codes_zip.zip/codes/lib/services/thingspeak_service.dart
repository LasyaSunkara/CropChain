import 'package:http/http.dart' as http;
import 'dart:convert';

class ThingSpeakService {
  static const String _baseUrl = 'https://api.thingspeak.com';
  final String channelId;
  final String writeApiKey;
  final String readApiKey;

  ThingSpeakService({
    required this.channelId,
    required this.writeApiKey,
    required this.readApiKey,
  });

  // Send data to ThingSpeak
  Future<bool> sendData(Map<String, dynamic> fieldData) async {
    try {
      var url = Uri.parse('$_baseUrl/update');
      var queryParams = {'api_key': writeApiKey};
      
      // Add field data to query parameters
      fieldData.forEach((key, value) {
        queryParams[key] = value.toString();
      });

      url = url.replace(queryParameters: queryParams);
      
      final response = await http.get(url);
      
      if (response.statusCode == 200) {
        // Returns the entry ID if successful
        return int.tryParse(response.body) != null;
      }
      return false;
    } catch (e) {
      print('Error sending to ThingSpeak: $e');
      return false;
    }
  }

  // Fetch data from ThingSpeak
  Future<List<dynamic>> fetchData({int results = 100}) async {
    try {
      final url = Uri.parse(
        '$_baseUrl/channels/$channelId/feeds.json?api_key=$readApiKey&results=$results',
      );
      
      final response = await http.get(url);
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return jsonData['feeds'];
      }
      return [];
    } catch (e) {
      print('Error fetching from ThingSpeak: $e');
      return [];
    }
  }
}