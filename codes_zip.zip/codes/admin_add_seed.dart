// admin_add_seed.dart
import 'dart:convert';
import 'package:http/http.dart';
import 'package:web3dart/web3dart.dart';

void main() async {
  final client = Web3Client('http://127.0.0.1:7545', Client());

  final privateKey = '0x891d295074472d151fc249f615a7073720c3bcacc5472e79b704fceaf5135925'; // Replace with your actual private key
  final credentials = EthPrivateKey.fromHex(privateKey);

  final contractAddress = EthereumAddress.fromHex('0xb792CEB63c390Ca3C5ed3afD1C3DEd270882B271');

  final abi = jsonEncode([
    {
      "inputs": [
        {"internalType": "string", "name": "qrCode", "type": "string"},
        {"internalType": "string", "name": "seedName", "type": "string"},
        {"internalType": "string", "name": "batchNo", "type": "string"},
        {"internalType": "string", "name": "supplier", "type": "string"},
        {"internalType": "string", "name": "sensorType", "type": "string"},
        {"internalType": "string", "name": "sensorValue", "type": "string"}
      ],
      "name": "addSeed",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ]);

  final contract = DeployedContract(
    ContractAbi.fromJson(abi, 'SeedStorage'),
    contractAddress,
  );

  final addSeed = contract.function('addSeed');

  // Seed data to add
  final List<Map<String, String>> seedDataList = [
    {
      "qrCode": "ud0JBCURKg",
      "seedName": "Hibiscus Rosa-Sinensis",
      "batchNo": "HSR-2024-IND",
      "supplier": "Green Leaf Seeds Pvt Ltd",
      "sensorType": "Moisture",
      "sensorValue": "72%"
    },
    {
      "qrCode": "je9SPquWCt",
      "seedName": "Bajra Pearl Millet",
      "batchNo": "BPM-2024-AP",
      "supplier": "Agro Bharat Seeds",
      "sensorType": "Temperature",
      "sensorValue": "24°C"
    },
    {
      "qrCode": "1kyXx9Q9Zr",
      "seedName": "Sunflower Hybrid SH-1",
      "batchNo": "SH1-2024-MH",
      "supplier": "SunAgro Seeds",
      "sensorType": "Temperature",
      "sensorValue": "26.5°C"
    },
  ];

  for (final data in seedDataList) {
    final txHash = await client.sendTransaction(
      credentials,
      Transaction.callContract(
        contract: contract,
        function: addSeed,
        parameters: [
          data["qrCode"],
          data["seedName"],
          data["batchNo"],
          data["supplier"],
          data["sensorType"],
          data["sensorValue"],
        ],
        maxGas: 300000,
      ),
      chainId: 1337,
    );
    print("✅ Seed '${data["seedName"]}' added with TX Hash: $txHash");
  }

  client.dispose();
}
